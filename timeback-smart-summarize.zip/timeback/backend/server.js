// server.js — Time Back backend
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import Anthropic from "@anthropic-ai/sdk";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8787;

// Allow the Chrome extension to call us during dev
app.use(cors({ origin: true }));
app.use(express.json({ limit: "2mb" }));

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

// Average adult reads ~225 words per minute
const WORDS_PER_MIN = 225;

const SYSTEM_PROMPT = `You are Time Back's Smart Summarize engine. Your job: turn long content into a 30-second read.

For every input, respond with ONLY a valid JSON object — no preamble, no markdown fences, no commentary:

{
  "bullets": [string, string, string],     // exactly 3 bullets, each <= 20 words, capturing the ESSENTIAL takeaways
  "verdict": "Worth it" | "Skim it" | "Skip it",
  "rationale": string                       // 1-2 sentences explaining the verdict honestly
}

Verdict guide:
- "Worth it" = unique insight, important news, or directly actionable for a general reader
- "Skim it" = mostly known/derivative info with a few useful nuggets
- "Skip it" = clickbait, fluff, repetition of widely-known facts, or pure marketing

Be honest. Most internet content is "Skim it" or "Skip it" — don't reward filler.`;

app.post("/summarize", async (req, res) => {
  const { url, title, content, sourceType } = req.body || {};
  if (!content || content.trim().length < 50) {
    return res.status(400).json({ error: "Content too short to summarize." });
  }

  const wordCount = content.trim().split(/\s+/).length;
  const readingTimeMinutes = Math.max(1, Math.round(wordCount / WORDS_PER_MIN));

  const userMessage = `URL: ${url || "(none)"}
Title: ${title || "(none)"}
Source: ${sourceType || "page"}
Word count: ${wordCount}

--- CONTENT START ---
${content}
--- CONTENT END ---

Return the JSON object now.`;

  try {
    const response = await anthropic.messages.create({
      model: "claude-haiku-4-5",          // cheap + fast for high-volume classification
      max_tokens: 600,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }]
    });

    const text = response.content
      .filter(b => b.type === "text")
      .map(b => b.text)
      .join("")
      .trim();

    // Strip accidental code fences just in case
    const cleaned = text.replace(/^```(?:json)?\s*/i, "").replace(/```$/, "").trim();

    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (e) {
      console.error("Failed to parse model output:", text);
      return res.status(502).json({ error: "Model returned invalid JSON.", raw: text });
    }

    // Estimate minutes saved: reading the original minus a ~30s summary read
    const summaryReadingSeconds = 30;
    const minutesSaved = Math.max(0, readingTimeMinutes - Math.ceil(summaryReadingSeconds / 60));

    return res.json({
      ...parsed,
      readingTimeMinutes,
      summaryReadingSeconds,
      minutesSaved,
      wordCount
    });
  } catch (err) {
    console.error("Anthropic API error:", err);
    return res.status(500).json({ error: err.message || "Unknown error" });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`⏱  Time Back backend running on http://localhost:${PORT}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.warn("⚠️  ANTHROPIC_API_KEY is not set — set it in .env before calling /summarize");
  }
});
