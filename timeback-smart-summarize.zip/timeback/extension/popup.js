chrome.storage.local.get(["totalMinutesSaved", "actionsCount"], ({ totalMinutesSaved = 0, actionsCount = 0 }) => {
  document.getElementById("minutes").textContent = totalMinutesSaved;
  document.getElementById("actions").textContent = `${actionsCount} action${actionsCount === 1 ? "" : "s"}`;
  document.getElementById("hours").textContent = `${(totalMinutesSaved / 60).toFixed(1)} hrs`;
});
