// background.js — Time Back service worker

const BACKEND_URL = "http://localhost:8787/summarize";

// Register the right-click menu on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "timeback-summarize-page",
    title: "Time Back: Summarize this page",
    contexts: ["page", "selection"]
  });
  chrome.contextMenus.create({
    id: "timeback-summarize-selection",
    title: "Time Back: Summarize selection",
    contexts: ["selection"]
  });
});

// Handle menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;

  let content = "";
  let sourceType = "page";

  if (info.menuItemId === "timeback-summarize-selection" && info.selectionText) {
    content = info.selectionText;
    sourceType = "selection";
  } else {
    // Pull the visible article-ish text from the page
    const [{ result } = {}] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractPageText
    });
    content = result || "";
  }

  // Show the loading overlay immediately
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: showOverlay,
    args: [{ state: "loading" }]
  });

  try {
    const res = await fetch(BACKEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: tab.url,
        title: tab.title,
        content: content.slice(0, 20000), // hard cap on payload
        sourceType
      })
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Backend error ${res.status}: ${errText}`);
    }

    const data = await res.json();

    // Track minutes saved locally
    const { totalMinutesSaved = 0, actionsCount = 0 } =
      await chrome.storage.local.get(["totalMinutesSaved", "actionsCount"]);
    await chrome.storage.local.set({
      totalMinutesSaved: totalMinutesSaved + (data.minutesSaved || 0),
      actionsCount: actionsCount + 1,
      lastAction: { url: tab.url, title: tab.title, at: Date.now(), data }
    });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: showOverlay,
      args: [{ state: "result", data }]
    });
  } catch (err) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: showOverlay,
      args: [{ state: "error", message: String(err.message || err) }]
    });
  }
});

// --- Functions injected into the page ---

function extractPageText() {
  // Prefer <article> if present, else main, else body
  const root =
    document.querySelector("article") ||
    document.querySelector("main") ||
    document.body;
  if (!root) return "";

  // Clone and strip noise
  const clone = root.cloneNode(true);
  clone.querySelectorAll("script,style,nav,footer,aside,noscript,iframe").forEach(n => n.remove());
  const text = clone.innerText || "";
  return text.replace(/\s+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}

function showOverlay({ state, data, message }) {
  const HOST_ID = "__timeback_overlay__";
  document.getElementById(HOST_ID)?.remove();

  const host = document.createElement("div");
  host.id = HOST_ID;
  host.style.cssText = `
    position: fixed; top: 20px; right: 20px; z-index: 2147483647;
    width: 380px; max-height: 80vh; overflow-y: auto;
    background: white; color: #1a1a1a;
    border-radius: 14px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.25), 0 2px 6px rgba(0,0,0,0.1);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 14px; line-height: 1.5;
    padding: 18px 20px;
    border: 1px solid rgba(0,0,0,0.08);
  `;

  const close = () => host.remove();

  const header = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <div style="font-weight:600;font-size:13px;letter-spacing:0.3px;color:#666;">⏱  TIME BACK</div>
      <button id="__tb_close" style="background:none;border:none;font-size:18px;cursor:pointer;color:#999;padding:0;line-height:1;">×</button>
    </div>
  `;

  if (state === "loading") {
    host.innerHTML = header + `
      <div style="padding:20px 0;text-align:center;color:#666;">
        <div style="display:inline-block;width:24px;height:24px;border:3px solid #eee;border-top-color:#3b82f6;border-radius:50%;animation:tb-spin 0.8s linear infinite;"></div>
        <div style="margin-top:12px;">Summarizing…</div>
      </div>
      <style>@keyframes tb-spin { to { transform: rotate(360deg); } }</style>
    `;
  } else if (state === "error") {
    host.innerHTML = header + `
      <div style="color:#b91c1c;background:#fef2f2;padding:12px;border-radius:8px;">
        <strong>Something went wrong.</strong><br>
        <span style="font-size:12px;">${message}</span>
      </div>
      <div style="margin-top:10px;font-size:12px;color:#888;">Is the backend running on localhost:8787?</div>
    `;
  } else if (state === "result" && data) {
    const verdictColor = {
      "Worth it": "#059669",
      "Skim it": "#d97706",
      "Skip it": "#dc2626"
    }[data.verdict] || "#666";

    const bulletsHtml = (data.bullets || [])
      .map(b => `<li style="margin-bottom:6px;">${escapeHtml(b)}</li>`)
      .join("");

    host.innerHTML = header + `
      <div style="display:inline-block;padding:4px 10px;border-radius:999px;background:${verdictColor}15;color:${verdictColor};font-weight:600;font-size:12px;margin-bottom:10px;">
        ${escapeHtml(data.verdict || "—")}
      </div>
      <ul style="margin:0 0 14px 18px;padding:0;">${bulletsHtml}</ul>
      <div style="font-size:12px;color:#555;background:#f8fafc;padding:10px;border-radius:8px;border-left:3px solid #3b82f6;">
        ${escapeHtml(data.rationale || "")}
      </div>
      <div style="margin-top:12px;font-size:11px;color:#888;display:flex;justify-content:space-between;">
        <span>⏱ ~${data.minutesSaved || 0} min saved</span>
        <span>${data.readingTimeMinutes || "?"} min read → ${data.summaryReadingSeconds || "?"} sec</span>
      </div>
    `;
  }

  document.body.appendChild(host);
  document.getElementById("__tb_close")?.addEventListener("click", close);

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }
}
