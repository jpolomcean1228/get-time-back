# Time Back — Smart Summarize (MVP)

A scrappy, working prototype of the first Time Back feature: **right-click anything → 3-bullet summary + a "worth your time?" verdict.**

The popup tracks lifetime minutes saved.

```
timeback/
├── extension/        # Chrome extension (Manifest V3)
│   ├── manifest.json
│   ├── background.js
│   ├── popup.html
│   ├── popup.js
│   └── icons/
└── backend/          # Node + Express server that calls Claude
    ├── server.js
    ├── package.json
    └── .env.example
```

---

## 1. Set up the backend

```bash
cd backend
npm install
cp .env.example .env
# Open .env and paste your key:  ANTHROPIC_API_KEY=sk-ant-...
npm start
```

You should see:
```
⏱  Time Back backend running on http://localhost:8787
```

Get an API key at <https://console.anthropic.com/>.

Quick health check:
```bash
curl http://localhost:8787/health
# {"ok":true}
```

---

## 2. Load the Chrome extension

1. Open `chrome://extensions` in Chrome (or any Chromium browser — Edge, Brave, Arc).
2. Toggle **Developer mode** on (top right).
3. Click **Load unpacked**.
4. Select the `timeback/extension` folder.
5. Pin the Time Back icon to your toolbar for easy access.

---

## 3. Try it

- Open any article (a long blog post, a Wikipedia page, a news story).
- Right-click anywhere on the page → **Time Back: Summarize this page**.
- An overlay appears in the top-right corner with:
  - A **verdict badge** (Worth it / Skim it / Skip it)
  - **3 bullets** with the core takeaways
  - A **rationale** explaining the verdict
  - Minutes saved + reading-time comparison

You can also highlight a passage and pick **Time Back: Summarize selection**.

Click the extension icon to see your lifetime time saved.

---

## How it works

```
Right-click  →  background.js extracts page text
             →  POST localhost:8787/summarize
             →  server.js calls Claude Haiku 4.5 with a strict JSON system prompt
             →  returns { bullets, verdict, rationale, minutesSaved }
             →  background.js injects an overlay onto the page
             →  storage.local accumulates totalMinutesSaved
```

**Model:** `claude-haiku-4-5` — chosen for cost and speed since this is a high-volume classification task. You can swap to `claude-sonnet-4-6` in `backend/server.js` for higher-quality summaries on long-form content.

**Minutes saved heuristic:** `(words / 225) − 0.5 min summary read`. Conservative on purpose — the weekly report needs to be believable.

---

## What's intentionally missing (MVP cuts)

- No user accounts / auth — single-user local-only.
- No production hosting — backend is localhost.
- No analytics, error tracking, or A/B.
- No streaming responses (one shot, ~2 sec round-trip).
- No PDF or YouTube transcript handling yet — just visible page text.

These slot into the v0.2 backlog.

---

## Next features in the Time Back roadmap

From the project plan:
1. ✅ **Smart Summarize** — you are here
2. **Inbox Triage** — Gmail OAuth + reply drafting
3. **Calendar Audit** — weekly meeting review
4. **Task Compressor** — paste a task, get a 5-min decision
5. **Weekly Time Back Report** — Sunday email rollup

---

## Troubleshooting

- **"Is the backend running?" in the overlay** → start the server: `cd backend && npm start`
- **CORS error in console** → `cors({ origin: true })` is already enabled; make sure you're hitting `http://localhost:8787`, not `https`.
- **JSON parse error from model** → very rare; the system prompt forces JSON. If it happens, the raw text comes back in the response so you can debug.
- **Want to use Sonnet instead of Haiku** → change the `model` field in `backend/server.js` to `claude-sonnet-4-6`.
